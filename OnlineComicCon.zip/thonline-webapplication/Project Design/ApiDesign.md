
模块 社团模块 :

    社团账户注册post:
    社团登录get：
    社团添加成员post：
    社团设置成员权限post：
    社团提交作品post：
    社团修改作品post：
    社团获取作品列表get：
    社团删除特定作品delete：
    社团申请展会post：
    社团取消申请delete：
    社团设置参展作品post：
    社团查看展会作品get：
    社团资料修改post：
    社团资料获取get：

模块 超级管理员模块：
    登录post：
    注销get：
    添加管理员post:
    删除管理员post：

模块 管理员模块：
    管理员登录get：
    管理员查看审核信息get：
    管理员处理审核信息post：
    管理员添加展会post：
    管理员删除展会delete：
    管理员设置展会信息post：

模块 个人模块
    个人模块注册post：
    个人用户登录get：
    个人用户注销get：
    个人用户修改信息post：
    个人用户获取社团邀请信息get：
    个人用户查看用户资料get：
    个人用户预约参展post：
    个人用户取消预约post：
    


    
    

    社团：club
    作品：product
    展会：Exhibition

