class UserSystem():
    def __init__(self):
        self.__user_list = []
        
    def validate_login(self, username, password):
        for c in self.__user_list:
            if c.get_userName() == username and c.check_password(password):
                return c
        return None
        
    def add_user(self,user):
        self.__user_list.append(user)
        
    def get_user_by_id(self,user_id):
        user = None
        for user in self.__user_list:
            if(user.get_id() == user_id):
                return user
        return 0
    
    def get_user_list(self):
        return self.__user_list