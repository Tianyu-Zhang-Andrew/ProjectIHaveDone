package com.mikason.PropView.services;

//@RunWith(SpringRunner.class)
//@SpringBootTest
//@Slf4j
//public class PropertyServiceTest {
//    @Autowired
//    private PropertyService service;
//
//    private Property getProperty() {
//        return new Property("", "1", "Sydney","Rd", "Sydney","NSW", "Australia", "2000");
//    }
//    @Test
//    public void testSavePropertyResultInSuccess() {
//        Property prop = service.saveProperty(getProperty());
//        Assert.assertNotNull(prop.getId());
//    }
//
//    @Test(expected = DatabaseException.class)
//    public void testSaveSameAddressTwiceResultInDatabaseException() {
//        Property prop = service.saveProperty(getProperty());
//        Assert.assertNotNull(prop.getId());
//
//        prop = service.saveProperty(getProperty());
//
//    }
//}
