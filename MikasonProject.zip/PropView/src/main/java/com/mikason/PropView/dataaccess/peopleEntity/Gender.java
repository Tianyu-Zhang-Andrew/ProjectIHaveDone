package com.mikason.PropView.dataaccess.peopleEntity;

public enum Gender {
    Male, Female, Other
}
