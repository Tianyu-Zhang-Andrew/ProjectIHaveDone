from abc import ABC

class Event(ABC):
    def __init__(self,name,status,start_time,end_time,last_cancel_time,convener,max_attendee,topic,class_type):
        self.__name = name
        self.__status = status
        self.__start_time = start_time
        self.__end_time = end_time
        self.__last_cancel_time = last_cancel_time
        self.__convener = convener
        self.__max_attendee = max_attendee
        self.__topic = topic
        self.__attendee_list = []    
        self.__class_type = class_type
        
    def add_attendee_to_list(self,attendee):
        self.__attendee_list.append(attendee)
        
    def remove_attendee_from_list(self,attendee):
        self.__attendee_list.remove(attendee)
    
    def get_name(self):
        return self.__name
    
    def get_attendee_list(self):
        return self.__attendee_list
    
    def get_status(self):
        return self.__status
    
    def change_status(self,status):
        self.__status = status
        
    def get_convener(self):
        return self.__convener
    
    def get_max_attendee(self):
        return self.__max_attendee
    
    def get_last_cancel_time(self):
        return self.__last_cancel_time
    
    def get_topic(self):
        return self.__topic
    
    def get_start_time(self):
        return self.__start_time
    
    def get_end_time(self):
        return self.__end_time
    
    def get_type(self):
        return self.__class_type
            
class Course(Event):
    def __init__(self,name,status,start_time,end_time,last_cancel_time,convener,max_attendee,topic,presenter,event_number):
        super().__init__(name,status,start_time,end_time,last_cancel_time,convener,max_attendee,topic,"course")
        self.__presenter = presenter
        self.__event_number = event_number
        
    def get_presenter(self):
        return self.__presenter
    
    def get_event_number(self):
        return self.__event_number

class Session(Event):
    def __init__(self,status,start_time,end_time,last_cancel_time,convener,topic,presenter,belong_to_seminar):
        super().__init__('',status,start_time,end_time,last_cancel_time,convener,'',topic,"session")
        self.__presenter = presenter
        self.__belong_to_seminar = belong_to_seminar
        
    def get_belong_to_seminar(self):
        return self.__belong_to_seminar
    
    def get_presenter(self):
        return self.__presenter
        
class Seminar(Event):
    def __init__(self,name,status,start_time,end_time,last_cancel_time,convener,max_attendee,event_number):
        super().__init__(name,status,start_time,end_time,last_cancel_time,convener,max_attendee,'',"seminar")
        self.__attendee_list = []
        self.__session_list = []
        self.__event_number = event_number
        
    def get_event_number(self):
        return self.__event_number
        
    def add_session_to_list(self,session):
        self.__session_list.append(session)
        
    def remove_session_from_list(self,session):
        self.__session_list.append(session)
        
    def get_session_list(self):
        return self.__session_list