package com.mikason.PropView.Exception.databaseException;

public class DatabaseException  extends RuntimeException {
    public DatabaseException(Throwable cause) {
        super(cause);
    }
}
