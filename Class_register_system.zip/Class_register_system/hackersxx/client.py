import csv
from user import Trainee,Trainer
from user_system import UserSystem

def creat_system():
    system = UserSystem()
    
    with open('user.csv',newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if(row['role'] == "trainee"):
                user = Trainee(row['name'],row['password'],row['zID'],row['email'])
            elif(row['role'] == "trainer"):
                user = Trainer(row['name'],row['password'],row['zID'],row['email'])
                
            system.add_user(user)
            
        return system
    
    
    