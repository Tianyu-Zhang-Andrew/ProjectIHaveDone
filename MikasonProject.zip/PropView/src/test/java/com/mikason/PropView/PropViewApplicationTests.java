package com.mikason.PropView;

//public class PropViewApplicationTests
//		extends TestCase
//{
//	/**
//	 * Create the test case
//	 *
//	 * @param testName name of the test case
//	 */
//	public PropViewApplicationTests( String testName )
//	{
//		super( testName );
//	}
//
//	/**
//	 * @return the suite of tests being tested
//	 */
//	public static Test suite()
//	{
//		return new TestSuite( PropViewApplicationTests.class );
//	}
//
//	/**
//	 * Rigourous Test :-)
//	 */
//	public void testApp()
//	{
//		assertTrue( true );
//	}
//}

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PropViewApplicationTests {

	@Test
	public void contextLoads() {
	}

}
