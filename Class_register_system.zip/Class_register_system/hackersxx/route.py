from flask import render_template, request, redirect, url_for
from flask_login import current_user, login_required, login_user, logout_user
from server import app, system
from EMS_system import EMS_system
from event import Course,Session,Seminar
from datetime import datetime

ems = EMS_system(system)

@app.route('/')
def home():
    return render_template('base.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form["username"];
        password = request.form["password"];
        user = system.validate_login(username,password)
        if user is not None:
            login_user(user)
            return redirect(url_for('Opened_event'))
    return render_template('log_in.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html',user = current_user)

@app.route('/openevent')
@login_required
def Opened_event():
    return render_template('opened_events.html',system = ems)

@app.route('/show/<event_number>')
@login_required
def Show_detail(event_number):    
    event = ems.get_event_from_number(event_number)
    
    in_this_event = False
    for client in event.get_attendee_list():
        if client == current_user:
            in_this_event = True                
    return render_template('show_detail.html',event = event,user = current_user,in_this_event = in_this_event)

@app.route('/post')
@login_required
def post_event():
    return render_template('post.html')

@app.route('/post/postcourse',methods = ["GET","POST"])
@login_required
def post_course():
    if request.method == 'POST':
        name = request.form["course_name"];
        start_time = datetime.strptime(request.form['start_time'], "%Y-%m-%d")
        end_time = datetime.strptime(request.form['end_time'], "%Y-%m-%d")
        last_cancel_time = datetime.strptime(request.form['last_cancel_time'], "%Y-%m-%d")
        topic = request.form["topic"];
        max_attendee = request.form["max_attendee"];
        presenter = request.form["presenter"];
        event_number = request.form["course_number"];
        convener = current_user.get_userName()
        
        i = 7
        for member in system.get_user_list():
            if member.get_userName() == presenter and member.get_identity() == "trainer":
                i = 1
                break
                
        if i != 1:
            return render_template('error.html',i = i)
        
        posted_course = Course(name,"open",start_time,end_time,last_cancel_time,convener,max_attendee,topic,presenter,event_number)
        i = ems.post_event(posted_course)
        
        if i == 1:            
            return render_template('Confirm.html')
        else:
            return render_template('error.html',i = i)
        
    return render_template('post_course.html')

@app.route('/post/postseminar',methods = ["GET","POST"])
@login_required
def post_seminar():
    if request.method == 'POST':
        name = request.form["seminar_name"];
        start_time = datetime.strptime(request.form['seminar_start_time'], "%Y-%m-%d")
        end_time = datetime.strptime(request.form['seminar_end_time'], "%Y-%m-%d")
        last_cancel_time = datetime.strptime(request.form['last_cancel_time'], "%Y-%m-%d")
        event_number = request.form["seminar_number"];   
        max_attendee = request.form["session_max_attendee"];
        convener = current_user.get_userName()
        
        posted_seminar = Seminar(name,"open",start_time,end_time,last_cancel_time,convener,max_attendee,event_number)
        i = ems.post_event(posted_seminar)
        
        if i == 1:            
            return render_template('Confirm.html')
        else:
            return render_template('error.html',i = i)
    
    return render_template('post_seminar.html')

@app.route('/post/postseminar/<seminar_number>/addsession',methods = ["GET","POST"])
@login_required
def add_session(seminar_number):
    if request.method == 'POST':
        start_time = datetime.strptime(request.form['session_start_time'], "%Y-%m-%d-%H-%M")
        end_time = datetime.strptime(request.form['session_end_time'], "%Y-%m-%d-%H-%M")
        last_cancel_time = datetime.strptime(request.form['session_last_cancel_time'], "%Y-%m-%d-%H-%M")
        topic = request.form["session_topic"];
        
        presenter = request.form["session_presenter"];
        convener = current_user.get_userName()        
        posted_session = Session("open",start_time,end_time,last_cancel_time,convener,topic,presenter,seminar_number)
        i = ems.post_event(posted_session)
        
        if i == 1:            
            return render_template('Confirm.html')
        else:
            return render_template('error.html',i = i)
        
    return render_template('add_session.html')

@app.route('/show/<event_number>/join',methods = ["GET","POST"])
@login_required
def join_event(event_number):
    event = ems.get_event_from_number(event_number)
    convener = event.get_convener()
    if(convener == current_user.get_userName()):
        i = 3
        return render_template('error.html',i = i)
    
    i = ems.register_event(current_user,event)
        
    if i == 1:
        return render_template('Confirm.html')
    else:
        return render_template('error.html',i = i)
    
@app.route('/show/<event_number>/leave',methods = ["GET","POST"])
@login_required
def leave_event(event_number):
    event = ems.get_event_from_number(event_number)
    i = ems.cancel_register(current_user,event)
    
    if i == 1:
        return render_template('Confirm.html')
    else:
        return render_template('error.html', i = i)
    
@app.route('/show/<event_number>/close',methods = ["GET","POST"])
@login_required
def close_event(event_number):
    event = ems.get_event_from_number(event_number)
    i = ems.close_event(event)
    
    if i == 1:
        return render_template('Confirm.html')
    else:
        return render_template('error.html', i = i)
    
@app.route('/show/<event_number>/seeattendeelist',methods = ["GET","POST"])
@login_required
def see_attendee_list(event_number):
    event = ems.get_event_from_number(event_number)
    
    return render_template('attendee_list.html', attendee_list = event.get_attendee_list())