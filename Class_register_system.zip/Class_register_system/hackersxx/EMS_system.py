from abc import ABC
import time
from flask_login import current_user
from datetime import datetime

class EMS_system(ABC):
    def __init__(self,UserSystem):
        self.__accountSystem = UserSystem
        self.__courseList = []#the events on the dashboard
        self.__seminarList = []
    def get_account_system(self):
        return self.__accountSystem
    
    def get_current_course(self):
        return self.__courseList
    
    def get_current_seminar(self):
        return self.__seminarList
    
    def get_event_from_number(self,event_number):
        
        for event in self.__courseList:
            if event.get_event_number() == event_number:
                return event
        
        for event in self.__seminarList:
            if event.get_event_number() == event_number:
                return event
            
    def register_event(self,user,event):
        
        #If the event is opened
        if(event.get_status() == "open"):
            
            attendee_list = event.get_attendee_list()
            
            if(len(attendee_list) >= int(event.get_max_attendee())):
                return 10
            
            #Add the user to the event's attendee list
            event.add_attendee_to_list(user)
            
            #Add the event to the user's registered history
            eventList = user.get_registered_history_list()
            user.add_item_to_list(event,eventList)
            
            #Add the event to the user's current registered list
            eventList = user.get_current_registered_list()
            user.add_item_to_list(event,eventList)
            
            return 1
        
        #If the event has been closed or canceled
        else:
            return 0
        
    def cancel_register(self,user,event):
        
        #If it hasn't passed the last cancel time
        if event.get_last_cancel_time() > datetime.now():
            #Remove the user to the event's attendee list
            event.remove_attendee_from_list(user)
            
            #Remove the event to the user's current registered list
            eventList = user.get_current_registered_list()
            user.remove_item_from_list(event,eventList)
            
            return 1
        
        #If it has passed the last cancel time
        else:
            return 2
        
    def cancel_event(self,event):
        
        #If the current user is a trainer
        if(current_user.get_identity() == "trainer."):
            
            #If it hasn't passed the last cancel time
            if event.get_last_cancel_time() > time.strftime("%Y-%m-%d-%H-%M",time.localtime()):
                #Change the status of the evemt to canceled
                event.change_status("canceled")
                
                #remove the event from all the attendees' current registed list
                attendee = None
                attendeeList = event.get_attendee_list()
                for attendee in attendeeList:
                    eventList = attendee.get_current_registered_list()
                    attendee.remove_item_from_list(event,eventList)               
                
                #remove the event from dashboard
                if(event.get_type() == "course"):                
                    self.__courseList.remove(event)
                elif(event.get_type() == "seminar"):
                    self.__seminarList.remove(event)
                
                #Add the event to the cancel list of the trainer
                cancelList = current_user.get_canceled_event_list()
                current_user.add_item_to_list(event,cancelList)
                
                print("Cancel successful.")
                return 1
            
            #If it has passed the last cancel time
            else:                
                print("It's too late to cancel this event.")
                return 0
            
        #If the current user is not a trainer
        else:
            print("You have no authority to do this.")
            return 0
            
    def close_event(self,event):
            
        #If it has passed the end time of this event
        if event.get_end_time() < datetime.now():
            
            #remove the event from all the attendees' current registed list
            attendeeList = event.get_attendee_list()
            for attendee in attendeeList:
                eventList = attendee.get_current_registered_list()
                attendee.remove_item_from_list(event,eventList)   
                
            #remove the event from dashboard
            if(event.get_type() == "course"):                
                self.__courseList.remove(event)
            elif(event.get_type() == "seminar"):
                self.__seminarList.remove(event)
                
            return 1
        
        #If it hasn't passed the end time of this event
        else:
            return 4
                
                
    def post_event(self,event):
        
        if event.get_start_time()<= datetime.now():
            return 5
        
        if event.get_start_time() >= event.get_end_time():
            return 8
        
        if event.get_last_cancel_time() >= event.get_start_time():
            return 9
        
        #Add the event from dashboard
        if(event.get_type() == "course"):                
            self.__courseList.append(event)
        elif(event.get_type() == "seminar"):
            self.__seminarList.append(event)
        elif(event.get_type() == "session"):            
            
            seminar_number = event.get_belong_to_seminar()
            seminar = self.get_event_from_number(seminar_number)
            
            if event.get_start_time() > seminar.get_end_time():
                return 6
            
            seminar.add_session_to_list(event)
            
        #Add the event to the trainer's post history
        postList = current_user.get_posted_history_list()
        current_user.add_item_to_list(event,postList)
        
        return 1