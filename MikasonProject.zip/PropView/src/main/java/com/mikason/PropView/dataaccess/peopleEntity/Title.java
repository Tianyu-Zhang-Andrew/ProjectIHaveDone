package com.mikason.PropView.dataaccess.peopleEntity;

public enum Title {
    Dr, Miss, Mr, Mrs, Ms, Prof
}
