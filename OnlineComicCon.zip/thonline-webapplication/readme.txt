1. 已写完的表:
Club, ClubProduct, Product, ProductSpot, ExhibitionSpot, ClubSpot

2. 各表方法均在service里定义，serviceImp里面实现，
   在controller里写server, controller中各function的调用方法:

    //Save a product
    @Autowired
    private ProductService productService;

    Product product = new Product(100, "picture1", "name1", "type1");
    this.productService.saveProduct(product);

3.各表function:
Club表function:
    Club saveClub(Club club);
    Club editClub(Club club);
    void deleteClub(Club club);
    void deleteAllClub();
    List<Club> searchClub(Club club);
    List<Club> getAllClub();

ClubProduct表function:
    ClubProduct saveClubProduct(ClubProduct clubProduct);
    ClubProduct editClubProduct(ClubProduct oldClubProduct, ClubProduct newClubProduct);
    void deleteClubProduct(ClubProduct clubProduct);
    void deleteAllClubProduct();
    List<ClubProduct> searchClubProduct(Club club, Product product);
    List<ClubProduct> getAllClubProduct();

Product表function:
    Product saveProduct(Product product);
    Product editProduct(Product product);
    void deleteProduct(Product product);
    void deleteAllProduct();
    List<Product> searchProduct(Product product);
    List<Product> getAllProduct();

ProductSpot表function:
    ProductSpot saveProductSpot(ProductSpot productSpot);
    ProductSpot editProductSpot(ProductSpot oldProductSpot, ProductSpot newProductSpot);
    void deleteProductSpot(ProductSpot productSpot);
    void deleteAllProductSpot();
    List<ProductSpot> searchProductSpot(ExhibitionSpot exhibitionSpot, Product product);
    List<ProductSpot> getAllProductSpot();

ExhibitionSpot表function:
    ExhibitionSpot saveExhibitionSpot(ExhibitionSpot exhibitionSpot);
    ExhibitionSpot editExhibitionSpot(ExhibitionSpot exhibitionSpot);
    void deleteExhibitionSpot(ExhibitionSpot exhibitionSpot);
    void deleteAllExhibitionSpot();
    List<ExhibitionSpot> searchExhibitionSpot(ExhibitionSpot exhibitionSpot);
    List<ExhibitionSpot> getAllExhibitionSpot();

ClubSpot表function:
    ClubSpot saveClubSpot(ClubSpot clubSpot);
    ClubSpot editClubSpot(ClubSpot oldClubSpot, ClubSpot newClubSpot);
    void deleteClubSpot(ClubSpot clubSpot);
    void deleteAllClubSpot();
    List<ClubSpot> searchClubSpot(Club club, ExhibitionSpot exhibitionSpot);
    List<ClubSpot> getAllClubSpot();