from abc import ABC, abstractmethod
from flask_login import UserMixin

class User(ABC,UserMixin):
    
    __id = -1
    def __init__(self,userName,password,zID,email,identity):
        self.__id = self.generate_id()
        self.__userName = userName
        self.__password = password
        self.__zID = zID
        self.__email = email
        self.__identity = identity
        self.__registered_history_list = []
        self.__current_registered_list = []
    
    def generate_id(self):
        User.__id += 1
        return User.__id
    
    def get_id(self):
        return str(self.__id)
    
    def get_email(self):
        return self.__email
    
    def add_item_to_list(self,event,addedList):
        addedList.append(event)
    
    def remove_item_from_list(self,event,removedList):
        removedList.remove(event)
        
    def get_password(self):
        return self.__password
    
    def get_userName(self):
        return self.__userName
    
    def get_identity(self):
        return self.__identity
    
    def get_ZID(self):
        return self.__zID
    
    def get_registered_history_list(self):
        return self.__registered_history_list
    
    def get_current_registered_list(self):
        return self.__current_registered_list
    
    def check_password(self,password):
        if self.__password == password:
            return 1
        else:
            return 0
    
    @property
    def is_authenticated(self):
        return True

    @property
    def is_active(self):
        return True

    @property
    def is_anonymous(self):
        return False
    
    @abstractmethod
    def is_admin(self):
        pass
    
class Trainee(User):
    def __init__(self,name,password,ZID,email):
        super().__init__(name,password,ZID,email,"trainee")
        
    def is_admin(self):
        return True
    
class Trainer(User):
    def __init__(self,name,password,ZID,email):
        super().__init__(name,password,ZID,email,"trainer")
        
        self.__current_posted_list = []
        self.__posted_history_list = []
        self.__canceled_event_list = []
        
    def get_current_posted_list(self):
        return self.__current_posted_list
    
    def get_posted_history_list(self):
        return self.__posted_history_list
    
    def get_canceled_event_list(self):
        return self.__canceled_event_list
    
    def is_admin(self):
        return False
        